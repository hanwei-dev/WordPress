<?php if ( rwmb_meta( 'magsy_subheading' ) != '' ) : ?>
  <h2 class="entry-subheading">
    <?php echo esc_html( rwmb_meta( 'magsy_subheading' ) ); ?>
  </h2>
<?php endif; ?>